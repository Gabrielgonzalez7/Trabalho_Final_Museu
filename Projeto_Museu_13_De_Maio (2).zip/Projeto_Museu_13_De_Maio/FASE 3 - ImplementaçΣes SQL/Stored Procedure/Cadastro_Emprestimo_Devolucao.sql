USE MuseuTrezeDeMaio;
-- Cadastro de novo usu�rio

CREATE PROCEDURE sp_cadastrar_usuario
(
    @nome VARCHAR(250),
    @tipo VARCHAR(50),
    @telefone VARCHAR(25),
    @email VARCHAR(100),
    @endereco VARCHAR(250)
)
AS
BEGIN
    INSERT INTO usuarios (nome, tipo, telefone, email, endereco)
    VALUES (@nome, @tipo, @telefone, @email, @endereco);
END;

EXEC sp_cadastrar_usuario
    'Gabriel Argimon Gonzalez',
    'Estudante',
    '51999999999',
    'gabriel@email.com',
    'Rua Central, 123';

    Select * from usuarios;

    -- Registro de emprestimo 
    CREATE PROCEDURE sp_realizar_emprestimo
(
    @id_usuario INT,
    @id_material INT,
    @dataPrevista DATE
)
AS
BEGIN
    INSERT INTO emprestimos
    (id_usuario, id_material, data_devolucao_prevista)
    VALUES
    (@id_usuario, @id_material, @dataPrevista);

    UPDATE materiais_biblioteca
    SET quantidade_exemplares = quantidade_exemplares - 1
    WHERE id_material = @id_material;
END;

-- Devolu��o, fim do empr�stimo

CREATE PROCEDURE sp_devolver_material
(
    @id_emprestimo INT
)
AS
BEGIN
    UPDATE emprestimos
    SET
        data_devolucao_real = GETDATE(),
        status_emprestimo = 'Finalizado'
    WHERE id_emprestimo = @id_emprestimo;
END;

