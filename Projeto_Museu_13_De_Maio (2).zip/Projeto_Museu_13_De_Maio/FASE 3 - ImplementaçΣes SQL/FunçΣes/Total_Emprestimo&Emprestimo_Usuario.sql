USE MuseuTrezeDeMaio;

--Total de Empr�stimos

CREATE FUNCTION fn_total_emprestimos_autor
(
    @id_autor INT
)
RETURNS INT
AS
BEGIN
    DECLARE @total INT;

    SELECT 
        @total = COUNT(e.id_emprestimo)
    FROM emprestimos e
    JOIN materiais_biblioteca m 
        ON e.id_material = m.id_material
    WHERE m.id_autor = @id_autor;

    RETURN ISNULL(@total, 0);
END;

--Consultar o total de empr�simos de um autor especifico 
SELECT 
    a.nome,
    dbo.fn_total_emprestimos_autor(a.id_autor) AS total_emprestimos
FROM autores a;



-- Total de empr�stimo por usu�rio 

CREATE FUNCTION fn_total_emprestimos_usuario
(
    @id_usuario INT
)
RETURNS INT
AS
BEGIN
    DECLARE @total INT;

    SELECT @total = COUNT(*)
    FROM emprestimos
    WHERE id_usuario = @id_usuario;

    RETURN ISNULL(@total, 0);
END;
-- teste
SELECT nome,
dbo.fn_total_emprestimos_usuario(id_usuario) AS total_emprestimos
FROM usuarios;


