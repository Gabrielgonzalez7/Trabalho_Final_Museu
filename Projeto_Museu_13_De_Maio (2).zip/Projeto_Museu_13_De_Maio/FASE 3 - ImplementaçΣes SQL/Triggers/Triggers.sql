-- Auditoria

CREATE TRIGGER trg_auditoria
ON emprestimos
AFTER INSERT, UPDATE
AS
BEGIN
    -- INSERT
    IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO log_sistema (tabela, id_item, acao)
        SELECT 'emprestimos', id_emprestimo, 'INSERT'
        FROM inserted;
    END
    
    -- UPDATE
    IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO log_sistema (tabela, id_item, acao)
        SELECT 'emprestimos', id_emprestimo, 'UPDATE'
        FROM inserted;
    END
END;
GO

-- Auditoria materiais_biblioteca
CREATE TRIGGER trg_auditoria_materiais
ON materiais_biblioteca
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    -- INSERT
    IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO log_sistema (tabela, id_item, acao)
        SELECT 'materiais_biblioteca', id_material, 'INSERT'
        FROM inserted;
    END
    
    -- UPDATE
    IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO log_sistema (tabela, id_item, acao)
        SELECT 'materiais_biblioteca', id_material, 'UPDATE'
        FROM inserted;
    END
    
    -- DELETE
    IF NOT EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO log_sistema (tabela, id_item, acao)
        SELECT 'materiais_biblioteca', id_material, 'DELETE'
        FROM deleted;
    END
END;
GO