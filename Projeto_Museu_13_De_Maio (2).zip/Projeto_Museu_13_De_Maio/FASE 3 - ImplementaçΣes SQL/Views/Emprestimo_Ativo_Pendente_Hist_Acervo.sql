USE MuseuTrezeDeMaio;
GO
-- Empr�stimos ativos

CREATE VIEW vw_emprestimos_ativos AS
SELECT  e.id_emprestimo, u.nome AS usuario, m.titulo AS material, e.data_emprestimo, e.data_devolucao_prevista
FROM emprestimos e
JOIN usuarios u ON e.id_usuario = u.id_usuario
JOIN materiais_biblioteca m ON e.id_material = m.id_material
WHERE e.status_emprestimo = 'Ativo';
GO

SELECT * FROM vw_emprestimos_ativos;
GO
-- Empr�timos pendentes
CREATE VIEW vw_emprestimos_pendentes AS
SELECT e.id_emprestimo, u.nome AS usuario, m.titulo AS material, e.data_devolucao_prevista
FROM emprestimos e
JOIN usuarios u 
    ON e.id_usuario = u.id_usuario
JOIN materiais_biblioteca m 
    ON e.id_material = m.id_material
WHERE 
    e.status_emprestimo = 'Ativo'
    AND e.data_devolucao_prevista < GETDATE();
GO

    SELECT * FROM vw_emprestimos_pendentes;
GO



-- Hist�rico do acervo
CREATE VIEW vw_acervo_historico AS
SELECT titulo, tipo, data_item, local_origem, doador
FROM acervo_historico;
GO
Select * from vw_acervo_historico;
GO

-- By: Matheus
-- Livros Dispon�veis
CREATE VIEW vw_livros_disponiveis AS
SELECT 
    titulo,
    autor_desconhecido as autor,
    ano_publicacao,
    editora
FROM materiais_biblioteca 
WHERE tipo = 'Livro' AND disponivel = 1;
GO

SELECT *
FROM vw_livros_disponiveis